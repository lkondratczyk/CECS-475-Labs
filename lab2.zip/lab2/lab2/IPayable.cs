﻿using System;

public interface IPayable{
    decimal GetPaymentAmount(); // calculate payment; no implementation
} // end interface IPayable
